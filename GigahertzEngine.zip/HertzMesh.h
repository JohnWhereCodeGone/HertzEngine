#pragma once
#include <vector>
#include "Vertex.h"
#include "Texture/HertzTexture.h"
#include "HertzShader.h"


class HertzMesh
{

private:


public:
	HertzMesh();
	~HertzMesh();

};

