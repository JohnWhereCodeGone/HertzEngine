//#pragma once
//#include "glad/glad.h"
//#include "glfw3.h"
//
//class HertzInitialize
//{
//	struct Data
//	{
//		GLFWwindow* window;
//	};
//
//	Data Initialize(int iwidth, int iheight);
//	void RenderTrigs();
//	static void framebuffer_size_callback(GLFWwindow* window, int width, int height);
//
//};