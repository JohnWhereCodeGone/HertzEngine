#pragma once
class Debugger
{
public:
	static void BreakPoint();
};

