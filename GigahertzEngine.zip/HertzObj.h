//#pragma once
#include "HertzShader.h"
//#include <iostream>
//#include <vector>
//
//class string;
//
//
//struct Data
//{
//	std::vector<unsigned int> indices;
//};
//
//class HertzObj
//{
//
//public:
//	
//	
//	Data readOBJ(const char* filePath = "./Objects/cube.cpp");
//	
//
//	
//private:
//	Shader* shader;
//
//};
//
