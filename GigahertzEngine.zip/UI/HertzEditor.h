#pragma once
#include <imgui.h>
#include <imgui_impl_glfw.h>
#include <imgui_impl_opengl3.h>

class HertzEditor
{
public:
	static void EditorUI(GLFWwindow* window);
	
};

