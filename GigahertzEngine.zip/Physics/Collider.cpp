#include "Collider.h"
#include <iostream>
/*
Collider::Collider(ColliderType type, Transform trans)
{
	switch (type) {

	case SPHERE:
		std::cout << "Creating Sphere Collider at " << trans.GetPos().x << std::endl;
	}
	this->Radius = 10.0;
	//this->transform = transform;
}

Transform Collider::GetTransform()
{
	return this->transform;
}

*/
