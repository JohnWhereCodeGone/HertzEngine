#include "PhyiscsEngine.h"
/*/
bool PhyiscsEngine::CheckCollision(Collider& obj1, Collider& obj2)
{

	//bool collisiionX = obj1.GetTransform().GetPos();
	return true;
}
*/
