#pragma once
#include "../Transform.h"
#include "Collider.h"

/*
class PhyiscsEngine
{
	//bool isOf() { return (dynamic_cast<T*>(this) != NULL); }
	
	bool CheckCollision(Collider& obj1, Collider& obj2);
};
*/

