#pragma once
/*
#include "./glm.hpp";
#include "C:\Users\John Henry\Documents\my engine\GigahertzEngine\Transform.h" //CHANGE TO GOOD LOCAL PATH

enum ColliderType
{
	SPHERE,
	CUBE,
	CYLINDER
};

class Collider
{

public:

	Collider(ColliderType type, Transform transform);
	Transform GetTransform();

private:

	glm::vec3 volume;
	float Radius;
	Transform transform;

};
im a faggot*/

