//#include "hertzrender.h"
//#include "glfw3.h"
//
//void HertzInitialize::RenderTrigs(GLFWwindow * window)
//{
//	//input
//	processInput(window);
//
//	//rendering stuff here
//	glClearColor(0.2f, 0.3f, 0.3f, 1.0f);
//	glClear(GL_COLOR_BUFFER_BIT);
//
//	glUseProgram(shaderProgram);
//	glBindVertexArray(VAOs[0]);
//	glDrawArrays(GL_TRIANGLES, 0, 3);
//
//
//
//	glUseProgram(shaderProgramYellow);
//	glBindVertexArray(VAOs[1]);
//	glDrawArrays(GL_TRIANGLES, 0, 3);
//
//
//
//	// check and call events, and swap the buffers to prevent artifacts.
//	glfwSwapBuffers(window);
//	glfwPollEvents();
//}
//
